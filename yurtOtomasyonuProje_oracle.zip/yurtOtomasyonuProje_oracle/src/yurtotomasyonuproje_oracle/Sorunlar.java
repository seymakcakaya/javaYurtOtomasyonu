/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

/**
 *
 * @author hp
 */
public class Sorunlar {
    
    String ıd;
    String odaıd;
    String yorum;

    public Sorunlar(String ıd, String odaıd, String yorum) {
        this.ıd = ıd;
        this.odaıd = odaıd;
        this.yorum = yorum;
    }

    public String getId() {
        return ıd;
    }

    public void setId(String ıd) {
        this.ıd = ıd;
    }

    public String getOdaıd() {
        return odaıd;
    }

    public void setOdaıd(String odaıd) {
        this.odaıd = odaıd;
    }

    public String getYorum() {
        return yorum;
    }

    public void setYorum(String yorum) {
        this.yorum = yorum;
    }
    
}
