/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

/**
 *
 * @author hp
 */
public class ADMINN {
      String USER_NAME, PASSWORD, FNAME, LNAME;
      int ID;

    public ADMINN( int ID,String USER_NAME, String FNAME, String LNAME, String PASSWORD) {
        this.USER_NAME = USER_NAME;
        this.PASSWORD = PASSWORD;
        this.FNAME = FNAME;
        this.LNAME = LNAME;
        this.ID = ID;
    }

    public String getUSER_NAME() {
        return USER_NAME;
    }

    public void setUSER_NAME(String USER_NAME) {
        this.USER_NAME = USER_NAME;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public String getFNAME() {
        return FNAME;
    }

    public void setFNAME(String FNAME) {
        this.FNAME = FNAME;
    }

    public String getLNAME() {
        return LNAME;
    }

    public void setLNAME(String LNAME) {
        this.LNAME = LNAME;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
      
}
