/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;


public class OgrenciBilgileri {
    private String FNAME;
 private String LNAME;
private String TCNO;
private String BDATE;
private String BOLUM;
private String E_POSTA;
private String EL_NO;
private String ODA_NO;
private String KAYITNO;
private String veli_ad;
private String veli_soyad;
private String veli_telefon;
private String veli_adres;
//ogr_ad,ogr_soyad, ogr_bölüm,tcno,ogr_DOB,ogr_eposta,ogr_tel,ogr_oda,ogr_kayıt,veli_ad,veli_soyad, veli_telefon,veli_adres
    public OgrenciBilgileri(String FNAME, String LNAME,String BOLUM ,String TCNO, String BDATE ,String E_POSTA, String EL_NO, String ODA_NO,  String KAYITNO,
            String veli_ad, String veli_soyad, String veli_telefon, String veli_adres) {
        this.FNAME = FNAME;
        this.LNAME = LNAME;
        this.TCNO = TCNO;
        this.BDATE = BDATE;
        this.BOLUM = BOLUM;
        this.E_POSTA = E_POSTA;
        this.EL_NO = EL_NO;
        this.ODA_NO = ODA_NO;
        this.veli_ad = veli_ad;
        this.veli_soyad = veli_soyad;
        this.veli_telefon = veli_telefon;
        this.veli_adres = veli_adres;
        this.KAYITNO = KAYITNO;
    }

    public String getVeli_adres() {
        return veli_adres;
    }

    public void setVeli_adres(String veli_adres) {
        this.veli_adres = veli_adres;
    }



    public String getVeli_ad() {
        return veli_ad;
    }

    public void setVeli_ad(String veli_ad) {
        this.veli_ad = veli_ad;
    }

    public String getVeli_soyad() {
        return veli_soyad;
    }

    public void setVeli_soyad(String veli_soyad) {
        this.veli_soyad = veli_soyad;
    }

    public String getVeli_telefon() {
        return veli_telefon;
    }

    public void setVeli_telefon(String veli_telefon) {
        this.veli_telefon = veli_telefon;
    }

  


    public String getFNAME() {
        return FNAME;
    }

    public void setFNAME(String FNAME) {
        this.FNAME = FNAME;
    }

    public String getLNAME() {
        return LNAME;
    }

    public void setLNAME(String LNAME) {
        this.LNAME = LNAME;
    }

    public String getTCNO() {
        return TCNO;
    }

    public void setTCNO(String TCNO) {
        this.TCNO = TCNO;
    }

    public String getBDATE() {
        return BDATE;
    }

    public void setBDATE(String BDATE) {
        this.BDATE = BDATE;
    }

    public String getBOLUM() {
        return BOLUM;
    }

    public void setBOLUM(String BOLUM) {
        this.BOLUM = BOLUM;
    }

    public String getE_POSTA() {
        return E_POSTA;
    }

    public void setE_POSTA(String E_POSTA) {
        this.E_POSTA = E_POSTA;
    }

    public String getEL_NO() {
        return EL_NO;
    }

    public void setEL_NO(String EL_NO) {
        this.EL_NO = EL_NO;
    }

    public String getODA_NO() {
        return ODA_NO;
    }

    public void setODA_NO(String ODA_NO) {
        this.ODA_NO = ODA_NO;
    }

    public String getKAYITNO() {
        return KAYITNO;
    }

    public void setKAYITNO(String KAYITNO) {
        this.KAYITNO = KAYITNO;
    }

//id
    
}
