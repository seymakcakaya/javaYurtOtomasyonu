/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;


public class izinClass {
String date;
String rdate;
String acıklama;
int id;
String kayıt;
    public izinClass(String date, String rdate, String acıklama, int id,String kayıt) {
        this.date = date;
        this.rdate = rdate;
        this.acıklama = acıklama;
        this.id = id;
        this.kayıt=kayıt;
    }

    public String getKayıt() {
        return kayıt;
    }

    public void setKayıt(String kayıt) {
        this.kayıt = kayıt;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRdate() {
        return rdate;
    }

    public void setRdate(String rdate) {
        this.rdate = rdate;
    }

    public String getAcıklama() {
        return acıklama;
    }

    public void setAcıklama(String acıklama) {
        this.acıklama = acıklama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    


}
