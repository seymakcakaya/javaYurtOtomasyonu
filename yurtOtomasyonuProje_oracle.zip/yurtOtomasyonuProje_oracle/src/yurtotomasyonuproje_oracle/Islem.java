/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.CallableStatement;


public class Islem {
    Connection con=null;
     Statement sta=null;
     PreparedStatement psta=null;
public static String a;
     
     //GİRİŞ İŞLEMLERİ
     
     public boolean Logın(String name,String password){
        String sorgu="Select * from USER_STD where NAME= ? and PASSWORD = ? ";
        try {
            psta=con.prepareStatement(sorgu);
            psta.setString(1,name);
            psta.setString(2,password);
            ResultSet rs=psta.executeQuery();
         boolean sonuç=rs.next();
         a=rs.getString("KAYITNO");
   System.out.println(a);
   
            //System.out.print(rs.next());
                    return sonuç;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);    
            return false;
        }

                 
     }
     public boolean uyeOLkontrol(String name,String lname,String kayıt){
        try {
            
        String sorgu="Select  FNAME, LNAME from student where KAYITNO=?";
            psta=con.prepareStatement(sorgu);
                  psta.setString(1,kayıt);
            ResultSet rs=psta.executeQuery();
          System.out.print("çalıştı1");
       
            while(rs.next()){
                System.out.print("çalıştı 2"); 
          
                String ogr_ad=rs.getString(1);
                String ogr_soyad=rs.getString(2);
                 //String ogr_kayıt=rs.getString(3);
            if(ogr_ad.equalsIgnoreCase(name)&&ogr_soyad.equalsIgnoreCase(lname))
            return true;
            
            
            }
            return false;
              
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
     }
     public void uyeol(String NAME,String PASSWORD,String KAYITNO){
        try {
            String sorgu="INSERT INTO USER_STD(NAME, PASSWORD,KAYITNO) VALUES(?,?,?)";
            psta=con.prepareStatement(sorgu);
            
            psta.setString(1, NAME);
            psta.setString(2, PASSWORD);
            psta.setString(3, KAYITNO);
            psta.executeUpdate();
      
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
        
     public void Okalan(){
        try {
            String sorgu="SELECT s.oda_no,s.fname,s.lname,b.kalanborc from student s,borclar b where s.kayıtno=b.bkayıtno and s.kayıtno=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(1,a);
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     
     }
     
    
     
     public boolean AdminLogın(String name,String password){
        String sorgu="Select * from ADMIN where USER_NAME= ? and PASSWORD = ? ";
        try {
            psta=con.prepareStatement(sorgu);
            psta.setString(1,name);
            psta.setString(2,password);
            ResultSet rs=psta.executeQuery();
            return rs.next();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);    
            return false;
        }}
     
     
     //ÖĞRENCİ İŞLEMELRİ
     
     public  ArrayList<OgrenciBilgileri> OgrenciB(){
         ArrayList<OgrenciBilgileri> list=new ArrayList<OgrenciBilgileri>();
         String sorgu=("Select s.*,VB.*,b.bolumadı from STUDENT S,VELI_B VB,BOLUM B WHERE S.KAYITNO=VB.VKAYITNO AND S.BOLUM=b.bolumıd");
        
        try {
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
             
            while(rs.next()){
                 String ogr_ad=rs.getString("FNAME");
                 String ogr_soyad=rs.getString("LNAME");
                 String ogr_bölüm=rs.getString("BOLUMADI");
                 String tcno=rs.getString("TCNO");
                 String ogr_DOB=rs.getString("BDATE");
                 String ogr_eposta=rs.getString("E_POSTA");
                 String ogr_tel=rs.getString("TEL_NO");
                 String ogr_oda=rs.getString("ODA_NO");
                 String ogr_kayıt=rs.getString("KAYITNO");
                 String veli_ad=rs.getString("VFNAME");
                 String veli_soyad=rs.getString("VLNAME");
                 String veli_telefon=rs.getString("VTEL_NO");
                 String veli_adres=rs.getString("VADRES");
                 list.add(new OgrenciBilgileri(ogr_ad,ogr_soyad, ogr_bölüm,tcno,ogr_DOB,ogr_eposta,ogr_tel,ogr_oda,ogr_kayıt,veli_ad,veli_soyad, veli_telefon,veli_adres));
                 //ogrencix.getFNAME(),ogrencix.getLNAME(),ogrencix.getBOLUM(),ogrencix.getTCNO(),ogrencix.getBDATE(),ogrencix.getE_POSTA(),ogrencix.getEL_NO()
                 //   ,ogrencix.getODA_NO(),ogrencix.getKAYITNO(),ogrencix.getVeli_ad(),ogrencix.getVeli_soyad(),ogrencix.getVeli_telefon(),ogrencix.getVeli_adres()
               
            }
            return list;
            
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return  null;
        }
         
     }
     public void ogrEkle(String  ad,   String soyad,String kayıt,String mail,String tc, String telefon, Integer bolum,String oda,String dob){
        try {
            String sorgu="INSERT INTO STUDENT(FNAME,LNAME,TCNO,BDATE,BOLUM,E_POSTA,TEL_NO,ODA_NO,KAYITNO)VALUES(?,?,?,?,?,?,?,?,?)";
           
            psta=con.prepareStatement(sorgu);
            psta.setString(1, ad);
            psta.setString(2, soyad);
            psta.setString(3,tc );
            psta.setString(4, dob);
            psta.setInt(5,bolum);
            psta.setString(6, mail);
            psta.setString(7, telefon);
            psta.setString(8, oda);
            psta.setString(9, kayıt);
            psta.executeUpdate();
         
           
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     public void öborc(String kayıt){
        try {
            String sorgu="ınsert ınto borclar(bkayıtno)values(?)";
            psta=con.prepareStatement(sorgu);
            psta.setString(1, kayıt);
            psta.executeQuery();
                    
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     /*try {
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","seyma");
            System.out.println("Bağlantı ve driver çalışıyor");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmıyor");
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı Çalışmadı");
        }*/
      public void Pborcö(String kayıt,int ödeme){        
           CallableStatement cstmt;
           try {
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","seyma");
            cstmt=con.prepareCall("{CALL BORC(?,?)}");
            cstmt.setString(1,kayıt);
            cstmt.setInt(2,ödeme);
             cstmt.execute();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmıyor");
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı Çalışmadı");
        }
          
      }
      public void toplusil(String kayıt){
         
            CallableStatement cstmt;
           try {
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","seyma");
            cstmt=con.prepareCall("{CALL SILME_PR(?)}");
            cstmt.setString(1,kayıt);
             cstmt.execute();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmıyor");
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı Çalışmadı");
        }
          
      }
     public void oborcekle(String kayıt,String oda){
        
           CallableStatement cstmt;
           try {
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","seyma");
            cstmt=con.prepareCall("{CALL BORC_G(?,?)}");
            cstmt.setString(1,kayıt);
             cstmt.setString(2, oda);
             cstmt.execute();
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmıyor");
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı Çalışmadı");
        }
         
     }
       public void veliekle(String ad   ,String soyad,String adres,String tel,String kayıt){
       
        try {
            String sorgu="INSERT INTO  VELI_B(VFNAME,VLNAME,VTEL_NO,VADRES,VKAYITNO)VALUES(?,?,?,?,?)";
           
            psta=con.prepareStatement(sorgu);
            psta.setString(1, ad);
            psta.setString(2, soyad);
            psta.setString(4,adres );
            psta.setString(3,tel);
            psta.setString(5, kayıt);
            psta.executeUpdate();
         
           
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     public int studentcount() {
        try {
            int label = 0;
            String sorgu = "SELECT COUNT(*) FROM STUDENT";
            
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);
            rs.next();
            label = rs.getInt(1);
            return label;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }        
    }
     public void ogrSil(String kayıt){
        try {
            String sorgu="Delete from STUDENT WHERE KAYITNO=?";
            psta = con.prepareStatement(sorgu);
            psta.setString(1, kayıt);
                        psta.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     }
     public void ogrSilV(String kayıt){
        try {
            String sorgu="Delete from VELI_B WHERE VKAYITNO=?";
            psta = con.prepareStatement(sorgu);
            psta.setString(1, kayıt);
           psta.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     }
     public void userupdate(String  ad,   String soyad,String kayıt,String mail,String tc, String telefon, Integer bolum,String oda,String dob){
        try {
            String sorgu = "Update STUDENT SET FNAME=?,LNAME=?,TCNO=?,BOLUM=?,E_POSTA=?,TEL_NO=?,ODA_NO=? WHERE KAYITNO=?";
            psta = con.prepareStatement(sorgu);
             psta.setString(1, ad);
            psta.setString(2, soyad);
            psta.setString(3,tc );
            psta.setInt(4,bolum);
            psta.setString(5, mail);
            psta.setString(6, telefon);
            psta.setString(7, oda);
            psta.setString(8, kayıt);
            psta.executeUpdate();
            System.out.print("userupdatebitti");
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     public void veliupdate (String v_ad, String v_soyad, String v_adres,String v_tel,String kayıt){
        try {
            String sorgu="UPDATE VELI_B SET VFNAME=?,VLNAME=?,VTEL_NO=?,VADRES=? WHERE VKAYITNO=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(1, v_ad);
            psta.setString(2, v_soyad);
            psta.setString(4, v_adres);          
            psta.setString(3, v_tel);
            psta.setString(5, kayıt);                       
            psta.executeUpdate();
 
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     }
       
//BORC İŞLEMLERİ
     
      public ArrayList<Borclar> Borc(){
        try {
            ArrayList<Borclar> borc=new ArrayList<Borclar>();
            String sorgu="SELECT b.bkayıtno,s.fname,s.lname,b.kalanborc FROM BORCLAR B JOIN STUDENT S ON b.bkayıtno=s.kayıtno";
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
            while(rs.next()){
                                               
                String id=rs.getString("BKAYITNO");
            String b_ad=rs.getString("FNAME");
            String name=rs.getString("LNAME" );
            int kalann=rs.getInt("KALANBORC");
                    
            borc.add(new Borclar(id,b_ad,name,kalann));
            }
            return borc;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
             
         
     }
      public void Borclar(String kayıtno){
        try {
            String sorgu="INSERT INTO BORCLAR(KAYITNO)VALUES(?)";
            
            psta=con.prepareStatement(sorgu);
                    psta.setString(1, kayıtno);
                    psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
         
         
     }
      public void BorcG(String no,int kalan){
        try {
            String sorgu=("UPDATE BORCLAR SET KALANBORC=? WHERE BKAYITNO=?");
            psta=con.prepareStatement(sorgu);
            psta.setString(2, no);
            psta.setInt(1, kalan);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
         public void BorcG2(String no,int kalan){
        try {
            String sorgu=("UPDATE BORCLAR SET KALANBORC=? WHERE BKAYITNO=?");
            psta=con.prepareStatement(sorgu);
            psta.setString(2, no);
            psta.setInt(1, kalan);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
      //BÖLÜM İŞLEMRİ 
      public ArrayList<Bolumm> BolumB(){
        try {
            ArrayList<Bolumm> bolum=new ArrayList<Bolumm>();
            String sorgu="SELECT * FROM BOLUM";
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
            while(rs.next()){
                int id=rs.getInt("BOLUMID");
            String b_ad=rs.getString("BOLUMADI");
            bolum.add(new Bolumm(id,b_ad));
            }
            return bolum;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
             
         
     }
       public void bolumEkle(String name){
        
        try {
            String sorgu="INSERT INTO BOLUM(BOLUMADI)VALUES(?)";
            psta=con.prepareStatement(sorgu);
            
            psta.setString(1, name);
              psta.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
                    
       }
       public void bolumSil(int id){
        try {
            String sorgu="Delete from BOLUM WHERE BOLUMID=?";
           psta=con.prepareStatement(sorgu);
           psta.setInt(1, id);
           psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
       public void bolumG(int id,String name){
        try {
            String sorgu="UPDATE BOLUM SET BOLUMADI=? WHERE BOLUMID=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(1,name);
            psta.setInt(2, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
      
     
     // GİDERLER KISMI
     public void giderEkle( int ELEKTRIK,int SU,int DOGALGAZ,int INTERNET,int GIDA,int PERSONEL,int DIGER ){
        try {
            String sorgu="INSERT INTO ODEMELER (ELEKTRIK ,SU,DOGALGAZ,INTERNET,GIDA,PERSONEL,DIGER) VALUES (?,?,?,?,?,?,?)";
            psta=con.prepareStatement(sorgu);
            psta.setInt(1,ELEKTRIK);
            psta.setInt(2, SU);
            psta.setInt(3, DOGALGAZ);
            psta.setInt(4, INTERNET);
            psta.setInt(5, GIDA);
            psta.setInt(6, PERSONEL);
            psta.setInt(7, DIGER);
            psta.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }

         
     }
    public ArrayList<ODEME>odemeler(){
        
        try {
            ArrayList<ODEME> list=new ArrayList<ODEME>();
            String sorgu="SELECT * FROM ODEMELER";
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
 
            while(rs.next()){
                int id=rs.getInt("ODEMEID");
             int e=rs.getInt("ELEKTRIK");
             int s=rs.getInt("SU");
             int d=rs.getInt("DOGALGAZ");
             int i=rs.getInt("INTERNET");
             int g=rs.getInt("GIDA");
             int p=rs.getInt("PERSONEL");
             int di=rs.getInt("DIGER");
                list.add(new ODEME(id,e,s,d,i,g,p,di));
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }}
   
     public void giderSil(int id){
        try {
            String sorgu="Delete from ODEMELER WHERE ODEMEID=?";
           psta=con.prepareStatement(sorgu);
           psta.setInt(1, id);
           psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
       public void giderG( int ELEKTRIK,int SU,int DOGALGAZ,int INTERNET,int GIDA,int PERSONEL,int DIGER,int ODEMEID){
        try {
            String sorgu="UPDATE ODEMELER SET ELEKTRIK=?,SU=?, DOGALGAZ=?,INTERNET=?, GIDA=?, PERSONEL=?, DIGER=? WHERE ODEMEID=?";
            psta=con.prepareStatement(sorgu);
            psta.setInt(1,ELEKTRIK);
            psta.setInt(2, SU);
            psta.setInt(3, DOGALGAZ);
            psta.setInt(4, INTERNET);
            psta.setInt(5, GIDA);
            psta.setInt(6, PERSONEL);
            psta.setInt(7, DIGER);
            psta.setInt(8, ODEMEID);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
public Islem() {
       
     
        
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","seyma");
            System.out.println("Bağlantı ve driver çalışıyor");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmıyor");
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı Çalışmadı");
        }
       
        
        }
public void kasalar( String ay,int DIGER ){
        try {
            String sorgu="INSERT INTO KASA (ODEMEAY,ÖDEMEMİKTARI) VALUES (?,?)";
            psta=con.prepareStatement(sorgu);
            psta.setString(1, ay);
            psta.setInt(2, DIGER);
            psta.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }

         
     }
 public int toplamMiktar(){
        try {
            int toplam=0;
            String sorgu="SELECT sum(ÖDEMEMİKTARI)FROM KASA";
            
            sta = con.createStatement();
            
            ResultSet rs = sta.executeQuery(sorgu);
            rs.next();
            toplam = rs.getInt(1);
            System.out.print(toplam);
            return toplam;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
 }
 public int secilen_ay_t(String ay){
        try {
            int toplam;
            String sorgu="SELECT SUM(ÖDEMEMİKTARI)FROM KASA  WHERE odemeay=?";
         
            psta=con.prepareStatement(sorgu);
            psta.setString(1,ay); 
          ResultSet rs=psta.executeQuery();
           
            //ResultSet rs=sta.executeQuery(sorgu);
            rs.next();
            toplam=rs.getInt(1);
           System.out.print(toplam);
            return toplam;
                    
                    
                   
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex); 
            return 0;
        }
 }
 
  public void ADMINEkle(String name,String Lname,String Uname,String PSWRD){
        
        try {
         
            String sorgu="INSERT INTO ADMIN(USER_NAME, PASSWORD, FNAME, LNAME) VALUES(?,?,?,?)";
            psta=con.prepareStatement(sorgu);
            
            psta.setString(1, name);
                psta.setString(2, Lname);
                    psta.setString(3, Uname);
                        psta.setString(4, PSWRD);
         
              psta.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
                    
       }
       public void ADMINSil(int id){
        try {
            String sorgu="Delete from ADMIN WHERE ID=?";
           psta=con.prepareStatement(sorgu);
           psta.setInt(1, id);
           psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
       public void ADMING(int id,String name,String Lname,String Uname,String PSWRD){
        try {
            //"Update STUDENT SET FNAME=?,LNAME=?,TCNO=?,BOLUM=?,E_POSTA=?,TEL_NO=?,ODA_NO=? WHERE KAYITNO=?";
            String sorgu="UPDATE ADMIN SET USER_NAME=?, PASSWORD=?, FNAME=?, LNAME=? WHERE ID=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(3,name);
            psta.setString(4, Lname);
            psta.setString(1, Uname);
            psta.setString(2, PSWRD);         
            psta.setInt(5, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
        public ArrayList<ADMINN>ADMINYAZ(){
        
        try {
            ArrayList<ADMINN> list=new ArrayList<ADMINN>();
            String sorgu="SELECT * FROM ADMIN";
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
            while(rs.next()){
                String ad=rs.getString("FNAME");
                 String soyad=rs.getString("LNAME");
                 String sifre=rs.getString("PASSWORD");
                 String kullanıcı=rs.getString("USER_NAME");
                int id=rs.getInt("ID");
       list.add(new ADMINN(id,kullanıcı,ad,soyad,sifre));
               
             
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }}
        
        
        
        
        
        
        
        
        public ArrayList<izinClass> izinler(){
        try {
            ArrayList<izinClass> list=new ArrayList<izinClass>();
            String sorgu="SELECT * FROM IZINLER WHERE IKAYIT=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(1,a);
            ResultSet rs=psta.executeQuery();
            while(rs.next()){
                String bas=rs.getString(2);
                String son=rs.getString(3);
                String acıklama=rs.getString(5);
                int id=rs.getInt(4);
                list.add(new izinClass(bas,son,acıklama,id,a));
           
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        }
         public void İZİNEkle(String date,String rdate,String acıklama,String kayıt){
        try {
            String sorgu="INSERT INTO IZINLER(IKAYIT,BAS,SON,ACIKLAMA) VALUES(?,?,?,?)";
            psta=con.prepareStatement(sorgu);
           psta.setString(1, kayıt);
            psta.setString(2, date);
            psta.setString(3,rdate );
            psta.setString(4, acıklama);
            psta.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
                    
       }
          public ArrayList<izinClass> Tümizinler(){
        try {
            ArrayList<izinClass> list=new ArrayList<izinClass>();
            String sorgu="SELECT * FROM IZINLER";
            psta=con.prepareStatement(sorgu);

            ResultSet rs=psta.executeQuery();
            while(rs.next()){
                String bas=rs.getString(2);
                String son=rs.getString(3);
                String acıklama=rs.getString(5);
                int id=rs.getInt(4);
                String kayıt=rs.getString(1);
                list.add(new izinClass(bas,son,acıklama,id,kayıt));
           
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        }
       public void İZİNSil(int id){
        try {
            String sorgu="Delete from IZINLER WHERE ID=?";
           psta=con.prepareStatement(sorgu);
           psta.setInt(1, id);
           psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
       public void sikayet(String sikayet,String oda){
        try {
            String sorgu="INSERT INTO SIKAYET(ODAID,YORUM) VALUES(?,?)";
            psta=con.prepareStatement(sorgu);
            psta.setString(1, oda);
            psta.setString(2,sikayet );
            psta.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
         public ArrayList<Sorunlar> SikayetListe(){
        try {
            ArrayList<Sorunlar> sorun=new ArrayList<Sorunlar>();
            String sorgu="SELECT * FROM SIKAYET";
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
            while(rs.next()){
            String odaid=rs.getString("ODAID");
            String yorum=rs.getString("YORUM");
            String id=rs.getString("ID");
            
            sorun.add(new Sorunlar(id,odaid,yorum));
            }
            return sorun;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
             
         
     }
          public void sikayetSil(int id){
        try {
            String sorgu="Delete from SIKAYET WHERE ID=?";
           psta=con.prepareStatement(sorgu);
           psta.setInt(1, id);
           psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
            public ArrayList<ODA2> ODALİSTE(){
        try {
            ArrayList<ODA2> oda=new ArrayList<ODA2>();
            String sorgu="SELECT * FROM ODA";
            sta=con.createStatement();
            ResultSet rs=sta.executeQuery(sorgu);
            while(rs.next()){

            int odaid=rs.getInt("ODA_ID");
            String no=rs.getString("ODA_NO");
            String kapasite=rs.getString("ODA_KAPASİTE");
            String aktif=rs.getString("ODA_A");
            
            oda.add(new ODA2(odaid,no,aktif,kapasite));
           
            }
            return oda;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
     }
            public void ODAEkle(String name,String KAPASİTE){
        
        try {
         
            String sorgu="INSERT INTO ODA (ODA_NO,ODA_KAPASİTE) VALUES(?,?)";
            psta=con.prepareStatement(sorgu);
            psta.setString(1, name);
            psta.setString(2, KAPASİTE);
            psta.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
                    
       }
       public void ODASil(int id){
        try {
            String sorgu="Delete from ODA WHERE ODA_ID=?";
           psta=con.prepareStatement(sorgu);
           psta.setInt(1, id);
           psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
       public void ODAG(int id,String name,String KAPASİTE){
        try {
            //"Update STUDENT SET FNAME=?,LNAME=?,TCNO=?,BOLUM=?,E_POSTA=?,TEL_NO=?,ODA_NO=? WHERE KAYITNO=?";
            String sorgu="UPDATE ODA SET ODA_NO=?, ODA_KAPASİTE=? WHERE ODA_ID=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(1,name);
            psta.setString(2, KAPASİTE);       
            psta.setInt(3, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }}
       
       //kullanıcı işlmeleri
       public void userG(String  id,String Uname,String PSWRD){
        try {
            //


            //"Update STUDENT SET FNAME=?,LNAME=?,TCNO=?,BOLUM=?,E_POSTA=?,TEL_NO=?,ODA_NO=? WHERE KAYITNO=?";
            String sorgu="UPDATE USER_STD SET NAME=?, PASSWORD=? WHERE KAYITNO=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(3,id);
            
            psta.setString(1, Uname);
            psta.setString(2, PSWRD);         
           
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
        public ArrayList<Sifre>userYAZ(){
        
        try {
            ArrayList<Sifre> list=new ArrayList<Sifre>();
            String sorgu="SELECT A.*,S.FNAME,S.LNAME FROM USER_STD A,STUDENT S WHERE A.KAYITNO=? and  A.KAYITNO=S.KAYITNO";
         psta=con.prepareStatement(sorgu);
            psta.setString(1,a);
            ResultSet rs=psta.executeQuery();
            while(rs.next()){
                String kayıt=rs.getString(3);
                String username=rs.getString(1);
                String password=rs.getString(2);
                String ad=rs.getString(4);
               String soyad=rs.getString(5);
       list.add(new Sifre(kayıt,username,password,ad,soyad));
               
             
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }}
        
               public ArrayList<Sifre>userYAZ2(){
        
        try {
            ArrayList<Sifre> list=new ArrayList<Sifre>();
            String sorgu="SELECT A.*,S.FNAME,S.LNAME FROM USER_STD A,STUDENT S WHERE   A.KAYITNO=S.KAYITNO";
         psta=con.prepareStatement(sorgu);
            ResultSet rs=psta.executeQuery();
            while(rs.next()){
                String kayıt=rs.getString(3);
                String username=rs.getString(1);
                String password=rs.getString(2);
                String ad=rs.getString(4);
               String soyad=rs.getString(5);
       list.add(new Sifre(kayıt,username,password,ad,soyad));
               
             
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Islem.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }}
        
        /*   
        public ArrayList<izinClass> izinler(){
        try {
            ArrayList<izinClass> list=new ArrayList<izinClass>();
            String sorgu="SELECT * FROM IZINLER WHERE IKAYIT=?";
            psta=con.prepareStatement(sorgu);
            psta.setString(1,a);
            ResultSet rs=psta.executeQuery();
            while(rs.next()){
                String bas=rs.getString(2);
                String son=rs.getString(3);
                String acıklama=rs.getString(5);
                int id=rs.getInt(4);
                list.add(new izinClass(bas,son,acıklama,id,a));*/
       
    }
     
  
     

