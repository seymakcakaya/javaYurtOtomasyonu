/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

/**
 *
 * @author hp
 */
public class Borclar {
    String kayıtno;
    String ad;
    String soyad;
    int kalan;

    public Borclar(String kayıtno, String ad, String soyad, int kalan) {
        this.kayıtno = kayıtno;
        this.ad = ad;
        this.soyad = soyad;
        this.kalan = kalan;
    }

    public String getKayıtno() {
        return kayıtno;
    }

    public void setKayıtno(String kayıtno) {
        this.kayıtno = kayıtno;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public int getKalan() {
        return kalan;
    }

    public void setKalan(int kalan) {
        this.kalan = kalan;
    }
    
}
