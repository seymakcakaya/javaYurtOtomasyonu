/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

/**
 *
 * @author hp
 */
public class ODA2 {
           int ODA_ID;
String ODA_NO;
String ODA_A;
String ODA_KAPASİTE;

    public ODA2(int ODA_ID, String ODA_NO, String ODA_A, String ODA_KAPASİTE) {
        this.ODA_ID = ODA_ID;
        this.ODA_NO = ODA_NO;
        this.ODA_A = ODA_A;
        this.ODA_KAPASİTE = ODA_KAPASİTE;
    }

    public int getODA_ID() {
        return ODA_ID;
    }

    public void setODA_ID(int ODA_ID) {
        this.ODA_ID = ODA_ID;
    }

    public String getODA_NO() {
        return ODA_NO;
    }

    public void setODA_NO(String ODA_NO) {
        this.ODA_NO = ODA_NO;
    }

    public String getODA_A() {
        return ODA_A;
    }

    public void setODA_A(String ODA_A) {
        this.ODA_A = ODA_A;
    }

    public String getODA_KAPASİTE() {
        return ODA_KAPASİTE;
    }

    public void setODA_KAPASİTE(String ODA_KAPASİTE) {
        this.ODA_KAPASİTE = ODA_KAPASİTE;
    }



}


