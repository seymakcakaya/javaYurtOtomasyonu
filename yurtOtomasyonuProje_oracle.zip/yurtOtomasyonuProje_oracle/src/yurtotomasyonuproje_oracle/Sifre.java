/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

/**
 *
 * @author hp
 */
public class Sifre {
    String kayıt;
    String username;
    String password;
String ad;
String soyad;
    public Sifre(String kayıt, String username, String password,String ad,String soyad) {
        this.kayıt = kayıt;
        this.username = username;
        this.password = password;
        this.ad=ad;
        this.soyad=soyad;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getKayıt() {
        return kayıt;
    }

    public void setKayıt(String kayıt) {
        this.kayıt = kayıt;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
}
