/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yurtotomasyonuproje_oracle;

/**
 *
 * @author hp
 */
public class ODEME {
   int ODEMEID;
int ELEKTRIK;
int SU;
int DOGALGAZ;
int INTERNET;
int GIDA;
int PERSONEL;
int DIGER;

    public ODEME(int ODEMEID, int ELEKTRIK, int SU, int DOGALGAZ, int INTERNET, int GIDA, int PERSONEL, int DIGER) {
        this.ODEMEID = ODEMEID;
        this.ELEKTRIK = ELEKTRIK;
        this.SU = SU;
        this.DOGALGAZ = DOGALGAZ;
        this.INTERNET = INTERNET;
        this.GIDA = GIDA;
        this.PERSONEL = PERSONEL;
        this.DIGER = DIGER;
    }

    public int getODEMEID() {
        return ODEMEID;
    }

    public void setODEMEID(int ODEMEID) {
        this.ODEMEID = ODEMEID;
    }

    public int getELEKTRIK() {
        return ELEKTRIK;
    }

    public void setELEKTRIK(int ELEKTRIK) {
        this.ELEKTRIK = ELEKTRIK;
    }

    public int getSU() {
        return SU;
    }

    public void setSU(int SU) {
        this.SU = SU;
    }

    public int getDOGALGAZ() {
        return DOGALGAZ;
    }

    public void setDOGALGAZ(int DOGALGAZ) {
        this.DOGALGAZ = DOGALGAZ;
    }

    public int getINTERNET() {
        return INTERNET;
    }

    public void setINTERNET(int INTERNET) {
        this.INTERNET = INTERNET;
    }

    public int getGIDA() {
        return GIDA;
    }

    public void setGIDA(int GIDA) {
        this.GIDA = GIDA;
    }

    public int getPERSONEL() {
        return PERSONEL;
    }

    public void setPERSONEL(int PERSONEL) {
        this.PERSONEL = PERSONEL;
    }

    public int getDIGER() {
        return DIGER;
    }

    public void setDIGER(int DIGER) {
        this.DIGER = DIGER;
    }
}
